package com.example.mynotes;



import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends Activity {
    Button btnClear;
    EditText txtNotes;
    final String file = new String("Notes.txt");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtNotes = findViewById(R.id.txtNotes);
        btnClear = findViewById(R.id.btnClear);
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearText();
            }
        });

        StringBuffer data = new StringBuffer();
        try{
            FileInputStream fileInputStream = openFileInput(file);
            InputStreamReader  inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

            String readString = bufferedReader.readLine();
            while(readString!=null){
                data.append(readString);
                readString = bufferedReader.readLine();
            }
            txtNotes.setText(data);
            bufferedReader.close();
            inputStreamReader.close();
            fileInputStream.close();
        }
        catch (IOException e){
            Toast.makeText(getBaseContext(),"Can't read file: "+e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }
    public void clearText(){
        txtNotes.setText("");
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            FileOutputStream fileout = openFileOutput(file, MODE_PRIVATE);
            OutputStreamWriter outputWriter = new OutputStreamWriter(fileout);
            outputWriter.write(txtNotes.getText().toString());
            outputWriter.flush();
            outputWriter.close();
        }
        catch (IOException e){
            Toast.makeText(getBaseContext(),"Can't save file "+e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//        try {
//            FileOutputStream fileout = openFileOutput(file, MODE_PRIVATE);
//            OutputStreamWriter outputWriter = new OutputStreamWriter(fileout);
//            outputWriter.write(txtNotes.getText().toString());
//            outputWriter.flush();
//            outputWriter.close();
//        }
//        catch (IOException e){
//            Toast.makeText(getBaseContext(),"Can't save file "+e.getMessage(),Toast.LENGTH_SHORT).show();
//        }
//    }
}